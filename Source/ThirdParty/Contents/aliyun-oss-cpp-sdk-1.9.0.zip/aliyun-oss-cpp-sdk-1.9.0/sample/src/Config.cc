#include <string>
#include "Config.h"

std::string Config::AccessKeyId = "";
std::string Config::AccessKeySecret = "";
std::string Config::Endpoint = "";
std::string Config::DirToDownload = "";
std::string Config::FileToUpload = "";
std::string Config::FileDownloadTo = "";
std::string Config::BigFileToUpload = "";
std::string Config::ImageFileToUpload = "";
std::string Config::CallbackServer = "";
std::string Config::CheckpointDir = "";
std::string Config::PublicKeyPath = "";
std::string Config::PrivateKeyPath = "";